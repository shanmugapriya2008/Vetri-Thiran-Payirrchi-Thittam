# ComicCraft

A clean FastAPI + Jinja2 AI comic generator based on the supplied project documentation.

## What it does

- Accepts story prompt, character, setting, tone and art style.
- Uses Gemini for a structured five-panel outline and story text.
- Uses Hugging Face Stable Diffusion for panel images when configured.
- Automatically falls back to local placeholder images if image AI fails.
- Retries transient AI errors.
- Shows the generated comic in a normal browser page.
- Exports the comic as a PDF.
- Includes JSON API and health endpoints.
- Includes an offline VS Code error decoder and PowerShell diagnostics.
- Responsive layout for Chrome, Firefox, Edge, Android and iOS browsers.

## VS Code / Windows PowerShell

Open the project folder in VS Code, then run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\scripts\setup.ps1
```

Put your Gemini key in `.env`:

```text
GEMINI_API_KEY=your_key_here
```

Optional image generation:

```text
HF_API_KEY=your_huggingface_token
```

Then:

```powershell
.\scripts\test.ps1
.\scripts\run.ps1
```

Browser preview:

- http://127.0.0.1:8000
- http://127.0.0.1:8000/docs
- http://127.0.0.1:8000/health

`127.0.0.1` works on the computer running the server. To open it on a phone connected to the same Wi-Fi, run the server with the supplied script and open `http://YOUR-PC-IP:8000` on the phone.

## Error decoder

Save a terminal traceback as `error.txt`, then:

```powershell
.\scripts\decode-error.ps1 .\error.txt
```

Or use VS Code's **ComicCraft: Diagnose** task.

The decoder is deliberately offline. It explains common errors rather than silently changing source code. The app itself handles expected AI failures with retries and fallbacks.

## Project tree

```text
ComicCraft/
├─ .env.example
├─ .gitignore
├─ README.md
├─ requirements.txt
├─ app/
│  ├─ __init__.py
│  ├─ config.py
│  ├─ main.py
│  ├─ models.py
│  ├─ routes.py
│  ├─ services/
│  │  ├─ comic.py
│  │  ├─ export.py
│  │  ├─ gemini.py
│  │  └─ images.py
│  └─ utils/
│     ├─ errors.py
│     └─ retry.py
├─ scripts/
│  ├─ setup.ps1
│  ├─ run.ps1
│  ├─ test.ps1
│  ├─ diagnose.ps1
│  ├─ open-browser.ps1
│  └─ decode-error.ps1
├─ tools/
│  ├─ error_decoder.py
│  └─ README.md
├─ templates/
│  ├─ base.html
│  ├─ index.html
│  ├─ comic_preview.html
│  └─ error.html
├─ static/
│  ├─ css/styles.css
│  ├─ js/app.js
│  ├─ generated/.gitkeep
│  └─ exports/.gitkeep
├─ tests/test_app.py
└─ .vscode/
   ├─ settings.json
   ├─ launch.json
   ├─ tasks.json
   └─ extensions.json
```
