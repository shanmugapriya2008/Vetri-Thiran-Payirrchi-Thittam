$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

$python = Join-Path (Get-Location) ".venv\Scripts\python.exe"
if (-not (Test-Path $python)) {
    Write-Host "Virtual environment not found. Running setup first..." -ForegroundColor Yellow
    & ".\scripts\setup.ps1"
}

Write-Host "Starting ComicCraft..." -ForegroundColor Cyan
Write-Host "Browser: http://127.0.0.1:8000" -ForegroundColor Green
Write-Host "Network/mobile: http://YOUR-PC-IP:8000" -ForegroundColor Green
Write-Host "API docs: http://127.0.0.1:8000/docs" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop." -ForegroundColor Yellow

& $python -m uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
