$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

Write-Host "=== ComicCraft setup ===" -ForegroundColor Cyan

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Error "Python is not installed or is not on PATH. Install Python 3.11+ and try again."
}

if (-not (Test-Path ".venv")) {
    Write-Host "Creating virtual environment..." -ForegroundColor Yellow
    python -m venv .venv
}

$python = Join-Path (Get-Location) ".venv\Scripts\python.exe"
$pip = Join-Path (Get-Location) ".venv\Scripts\pip.exe"

& $python -m pip install --upgrade pip
& $pip install -r requirements.txt

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example." -ForegroundColor Green
    Write-Host "Add your GEMINI_API_KEY to .env before real AI generation." -ForegroundColor Yellow
}

New-Item -ItemType Directory -Force -Path "static\generated" | Out-Null
New-Item -ItemType Directory -Force -Path "static\exports" | Out-Null

Write-Host ""
Write-Host "Setup complete." -ForegroundColor Green
Write-Host "Run: .\scripts\run.ps1" -ForegroundColor White
