param(
    [string]$Url = "http://127.0.0.1:8000"
)

Start-Process $Url
Write-Host "Opened $Url" -ForegroundColor Green
