param(
    [string]$LogFile = ""
)

$ErrorActionPreference = "Stop"

if ($LogFile -and (Test-Path $LogFile)) {
    $text = Get-Content $LogFile -Raw
} else {
    Write-Host "Paste the Python/FastAPI error below, then press Ctrl+Z and Enter (Windows), or use a log file:" -ForegroundColor Yellow
    $text = [Console]::In.ReadToEnd()
}

if (-not $text.Trim()) {
    Write-Host "No error text was supplied." -ForegroundColor Red
    exit 1
}

$decoder = Join-Path (Split-Path -Parent $PSScriptRoot) "tools\error_decoder.py"
$python = Join-Path (Split-Path -Parent $PSScriptRoot) ".venv\Scripts\python.exe"

if (Test-Path $python) {
    $text | & $python $decoder
} else {
    $text | python $decoder
}
