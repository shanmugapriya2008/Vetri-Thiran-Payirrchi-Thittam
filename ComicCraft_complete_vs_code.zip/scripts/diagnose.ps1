$ErrorActionPreference = "Continue"
Set-Location (Split-Path -Parent $PSScriptRoot)

Write-Host "=== ComicCraft diagnostics ===" -ForegroundColor Cyan

$python = Join-Path (Get-Location) ".venv\Scripts\python.exe"

if (Test-Path $python) {
    Write-Host "`nPython:" -ForegroundColor Yellow
    & $python --version
} else {
    Write-Host "`nVirtual environment: MISSING" -ForegroundColor Red
}

if (Test-Path ".env") {
    Write-Host ".env: found" -ForegroundColor Green
    $envText = Get-Content ".env" -Raw
    if ($envText -match "(?m)^GEMINI_API_KEY=\s*$") {
        Write-Host "GEMINI_API_KEY: not configured" -ForegroundColor Yellow
    } else {
        Write-Host "GEMINI_API_KEY: configured" -ForegroundColor Green
    }
} else {
    Write-Host ".env: MISSING" -ForegroundColor Red
}

Write-Host "`nHealth check:" -ForegroundColor Yellow
try {
    $health = Invoke-RestMethod "http://127.0.0.1:8000/health" -TimeoutSec 5
    $health | ConvertTo-Json
} catch {
    Write-Host "Server is not running at http://127.0.0.1:8000" -ForegroundColor Yellow
}

Write-Host "`nProvider check:" -ForegroundColor Yellow
try {
    $providers = Invoke-RestMethod "http://127.0.0.1:8000/health/providers" -TimeoutSec 5
    $providers | ConvertTo-Json
} catch {
    Write-Host "Provider endpoint unavailable because the server is not running." -ForegroundColor Yellow
}

Write-Host "`nCommon fixes:" -ForegroundColor Yellow
Write-Host "1. Run .\scripts\setup.ps1"
Write-Host "2. Put GEMINI_API_KEY=... in .env"
Write-Host "3. Run .\scripts\test.ps1"
Write-Host "4. Run .\scripts\run.ps1"
Write-Host "5. Open http://127.0.0.1:8000"
