import logging, uuid
log = logging.getLogger("comiccraft")

def error_id(exc: Exception) -> str:
    ident = uuid.uuid4().hex[:12]
    log.exception("[%s] ComicCraft error: %s", ident, exc)
    return ident
