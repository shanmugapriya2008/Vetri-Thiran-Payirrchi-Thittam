import asyncio
from collections.abc import Awaitable, Callable

async def retry(operation: Callable[[], Awaitable], attempts: int = 3):
    last = None
    for i in range(max(1, attempts)):
        try:
            return await operation()
        except Exception as exc:
            last = exc
            if i + 1 < attempts:
                await asyncio.sleep(1.5 * (2 ** i))
    raise last
