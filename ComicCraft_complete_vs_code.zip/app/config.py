from pathlib import Path
from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict

ROOT = Path(__file__).resolve().parent.parent

class Settings(BaseSettings):
    app_name: str = "ComicCraft"
    gemini_api_key: str | None = None
    gemini_text_model: str = "gemini-2.5-flash"
    hf_api_key: str | None = None
    hf_image_model: str = "stabilityai/stable-diffusion-xl-base-1.0"
    image_provider: str = "auto"
    ai_retries: int = 3
    max_panels: int = 5
    generated_dir: Path = ROOT / "static" / "generated"
    exports_dir: Path = ROOT / "static" / "exports"
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    def prepare(self):
        self.generated_dir.mkdir(parents=True, exist_ok=True)
        self.exports_dir.mkdir(parents=True, exist_ok=True)

@lru_cache
def settings():
    s = Settings(); s.prepare(); return s
