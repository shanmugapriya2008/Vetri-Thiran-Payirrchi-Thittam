from typing import Literal
from pydantic import BaseModel, Field

class PromptRequest(BaseModel):
    story_prompt: str = Field(min_length=3, max_length=3000)
    character_name: str = Field(min_length=1, max_length=80)
    setting: str = Field(min_length=1, max_length=120)
    tone: Literal["light-hearted", "dramatic", "poetic", "funny"] = "dramatic"
    art_style: Literal["anime", "pixel art", "comic book", "realistic"] = "comic book"

class PanelOutline(BaseModel):
    panel_number: int
    title: str
    scene_description: str
    image_prompt: str

class PanelStory(BaseModel):
    panel_number: int
    caption: str = ""
    narration: str = ""
    dialogue: str = ""

class ComicPanel(BaseModel):
    panel_number: int
    title: str
    scene_description: str
    image_prompt: str
    image_url: str
    caption: str = ""
    narration: str = ""
    dialogue: str = ""
