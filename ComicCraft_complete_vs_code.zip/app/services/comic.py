import asyncio, uuid
from pathlib import Path
from app.config import settings
from app.models import PromptRequest, ComicPanel
from app.services.gemini import outline, story
from app.services.images import generate
from app.services.export import make_pdf

async def create(req: PromptRequest):
    s = settings(); job = uuid.uuid4().hex; folder = s.generated_dir / job; warnings=[]
    outlines, w = await outline(req); warnings += w
    stories, w = await story(outlines, req); warnings += w
    results = await asyncio.gather(*(generate(p.image_prompt, p.panel_number, folder) for p in outlines))
    if any(provider == "local-fallback" for _, provider in results): warnings.append("One or more images used the local recovery image.")
    smap = {x.panel_number:x for x in stories}; panels=[]
    for p,(path,_) in zip(outlines,results):
        st=smap[p.panel_number]
        panels.append(ComicPanel(panel_number=p.panel_number,title=p.title,scene_description=p.scene_description,image_prompt=p.image_prompt,image_url=f"/static/generated/{job}/{path.name}",caption=st.caption,narration=st.narration,dialogue=st.dialogue))
    pdf_name=f"comic-{job}.pdf"; make_pdf(panels, folder, s.exports_dir/pdf_name)
    return job, panels, f"/static/exports/{pdf_name}", warnings
