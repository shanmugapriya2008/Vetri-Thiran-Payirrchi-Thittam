import asyncio
from pathlib import Path
from uuid import uuid4
from PIL import Image, ImageDraw, ImageFont
import httpx
from app.config import settings
from app.utils.retry import retry

async def _hf(prompt, path):
    s = settings()
    if not s.hf_api_key: raise RuntimeError("HF_API_KEY is not configured")
    url = f"https://router.huggingface.co/hf-inference/models/{s.hf_image_model}"
    headers = {"Authorization": f"Bearer {s.hf_api_key}"}
    async with httpx.AsyncClient(timeout=180) as client:
        r = await client.post(url, headers=headers, json={"inputs": prompt})
        r.raise_for_status(); path.write_bytes(r.content)

def _fallback(path, number, prompt):
    im = Image.new("RGB", (1200, 675), "#f1eadc"); d = ImageDraw.Draw(im)
    try: font = ImageFont.truetype("DejaVuSans-Bold.ttf", 42)
    except OSError: font = ImageFont.load_default()
    d.rectangle((25,25,1175,650), outline="#222", width=7)
    d.text((55,55), f"PANEL {number}", fill="#222", font=font)
    d.text((55,130), prompt[:700], fill="#333", font=font)
    im.save(path, "PNG")

async def generate(prompt, number, job_dir):
    s = settings(); job_dir.mkdir(parents=True, exist_ok=True)
    path = job_dir / f"panel-{number}-{uuid4().hex[:8]}.png"
    provider = s.image_provider.lower()
    if provider in ("auto", "huggingface") and s.hf_api_key:
        try:
            await retry(lambda: _hf(prompt, path), s.ai_retries)
            return path, "huggingface"
        except Exception:
            pass
    _fallback(path, number, prompt)
    return path, "local-fallback"
