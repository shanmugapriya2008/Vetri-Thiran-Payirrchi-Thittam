from pathlib import Path
from fpdf import FPDF
from app.models import ComicPanel

class PDF(FPDF):
    def footer(self):
        self.set_y(-12); self.set_font("Helvetica", size=8); self.cell(0, 8, f"ComicCraft - {self.page_no()}", align="C")

def make_pdf(panels: list[ComicPanel], image_root: Path, output: Path):
    pdf = PDF(); pdf.set_auto_page_break(True, 15)
    for p in panels:
        pdf.add_page(); pdf.set_font("Helvetica", "B", 18); pdf.multi_cell(0, 9, f"Panel {p.panel_number}: {p.title}")
        image = image_root / Path(p.image_url).name
        if image.exists(): pdf.image(str(image), w=175); pdf.ln(4)
        for title, value in (("Scene",p.scene_description),("Caption",p.caption),("Narration",p.narration),("Dialogue",p.dialogue)):
            pdf.set_font("Helvetica", "B", 11); pdf.multi_cell(0, 6, title)
            pdf.set_font("Helvetica", size=10); pdf.multi_cell(0, 6, value or "-"); pdf.ln(1)
    pdf.output(str(output)); return output
