import asyncio, json
import httpx
from app.config import settings
from app.models import PanelOutline, PanelStory
from app.utils.retry import retry

URL = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"

def _demo_outline(req):
    beats = ["The Beginning", "The Discovery", "The Challenge", "The Turning Point", "The New Dawn"]
    return [PanelOutline(panel_number=i+1, title=beats[i],
        scene_description=f"{req.character_name} experiences the next stage of the adventure in {req.setting}.",
        image_prompt=f"{req.art_style} comic illustration, {req.character_name}, {req.setting}, {req.tone}, cinematic lighting, consistent character design, no text, scene {i+1}") for i in range(5)]

def _demo_story(outlines, name):
    return [PanelStory(panel_number=p.panel_number, caption=p.title, narration=p.scene_description, dialogue=f"{name}: We keep moving forward!") for p in outlines]

async def _generate(prompt: str):
    s = settings()
    if not s.gemini_api_key:
        raise RuntimeError("GEMINI_API_KEY is not configured")
    payload = {"contents":[{"parts":[{"text":prompt}]}], "generationConfig":{"responseMimeType":"application/json"}}
    async with httpx.AsyncClient(timeout=90) as client:
        r = await client.post(URL.format(model=s.gemini_text_model), params={"key":s.gemini_api_key}, json=payload)
        r.raise_for_status()
        data = r.json()
    try:
        return data["candidates"][0]["content"]["parts"][0]["text"]
    except (KeyError, IndexError) as exc:
        raise RuntimeError("Gemini returned no text") from exc

async def outline(req):
    s = settings()
    if not s.gemini_api_key:
        return _demo_outline(req), ["Gemini key missing: demo outline used."]
    prompt = f'''Return ONLY valid JSON array with exactly 5 objects having keys panel_number,title,scene_description,image_prompt.
Story: {req.story_prompt}\nCharacter: {req.character_name}\nSetting: {req.setting}\nTone: {req.tone}\nArt style: {req.art_style}'''
    try:
        raw = await retry(lambda: _generate(prompt), s.ai_retries)
        data = json.loads(raw)
        panels = [PanelOutline.model_validate(x) for x in data]
        if len(panels) != s.max_panels: raise ValueError("Wrong panel count")
        return panels, []
    except Exception as exc:
        return _demo_outline(req), [f"Outline recovery used after AI error: {type(exc).__name__}."]

async def story(outlines, req):
    s = settings()
    if not s.gemini_api_key:
        return _demo_story(outlines, req.character_name), ["Gemini key missing: demo story used."]
    outline_json = json.dumps([p.model_dump() for p in outlines])
    prompt = f'''Return ONLY valid JSON array with one object per panel using keys panel_number,caption,narration,dialogue.
Character: {req.character_name}; tone: {req.tone}. Preserve panel numbers and continuity.
Outline: {outline_json}'''
    try:
        raw = await retry(lambda: _generate(prompt), s.ai_retries)
        data = json.loads(raw)
        stories = [PanelStory.model_validate(x) for x in data]
        if len(stories) != len(outlines): raise ValueError("Wrong story panel count")
        return stories, []
    except Exception as exc:
        return _demo_story(outlines, req.character_name), [f"Story recovery used after AI error: {type(exc).__name__}."]
