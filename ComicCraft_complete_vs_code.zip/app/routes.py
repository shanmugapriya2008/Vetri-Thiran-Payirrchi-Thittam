from fastapi import APIRouter, Request, Form
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from app.config import settings
from app.models import PromptRequest
from app.services.comic import create
from app.utils.errors import error_id

router=APIRouter(); templates=Jinja2Templates(directory="templates")

@router.get("/", response_class=HTMLResponse)
async def home(request: Request): return templates.TemplateResponse(request=request,name="index.html",context={"app_name":settings().app_name})

@router.post("/generate", response_class=HTMLResponse)
async def generate(request: Request, story_prompt: str=Form(...), character_name: str=Form(...), setting: str=Form(...), tone: str=Form(...), art_style: str=Form(...)):
    try:
        req=PromptRequest(story_prompt=story_prompt,character_name=character_name,setting=setting,tone=tone,art_style=art_style)
        job,panels,pdf,warnings=await create(req)
        return templates.TemplateResponse(request=request,name="comic_preview.html",context={"app_name":settings().app_name,"job_id":job,"panels":panels,"pdf_url":pdf,"warnings":warnings})
    except Exception as exc:
        return templates.TemplateResponse(request=request,name="error.html",context={"app_name":settings().app_name,"error_id":error_id(exc)},status_code=500)

@router.post("/generate-comic/json")
async def generate_json(req: PromptRequest):
    try:
        job,panels,pdf,warnings=await create(req)
        return {"success":True,"job_id":job,"panels":[p.model_dump() for p in panels],"pdf_url":pdf,"warnings":warnings}
    except Exception as exc:
        return JSONResponse(status_code=500,content={"success":False,"error_id":error_id(exc),"message":"Generation failed. Retry."})

@router.get("/health")
async def health(): return {"status":"ok","app":settings().app_name}

@router.get("/health/providers")
async def providers():
    s=settings(); return {"gemini_configured":bool(s.gemini_api_key),"huggingface_configured":bool(s.hf_api_key),"text_model":s.gemini_text_model,"image_model":s.hf_image_model}
