# Error Decoder

If the terminal shows an error, save it to `error.txt` and run:

```powershell
.\scripts\decode-error.ps1 .\error.txt
```

Or pipe an error into the decoder:

```powershell
Get-Content .\error.txt -Raw | .\.venv\Scripts\python.exe .\tools\error_decoder.py
```

The decoder is offline and only explains common Python/FastAPI/AI configuration errors.
It does not automatically rewrite source code, because silently changing code can create
new bugs. ComicCraft itself already retries AI calls and has local fallbacks for expected
AI-generation failures.
