"""
Small offline ComicCraft error decoder.

It does not hide or change the original traceback. It identifies common errors
and prints the likely cause plus the safest next command.
"""

import re
import sys


RULES = [
    (
        r"ModuleNotFoundError: No module named ['\"]fastapi['\"]",
        "FastAPI is not installed in the active environment.",
        ".\\scripts\\setup.ps1",
    ),
    (
        r"ModuleNotFoundError: No module named ['\"]google",
        "The Google GenAI SDK is missing.",
        ".\\scripts\\setup.ps1",
    ),
    (
        r"ModuleNotFoundError",
        "A Python dependency is missing or VS Code is using the wrong interpreter.",
        "Select .venv in VS Code, then run .\\scripts\\setup.ps1",
    ),
    (
        r"ValidationError",
        "The AI response or incoming request did not match the expected Pydantic structure.",
        "Retry first. The app already retries AI calls and falls back to local story data.",
    ),
    (
        r"GEMINI_API_KEY.*not configured|GEMINI_API_KEY",
        "The Gemini API key is missing or not loaded from .env.",
        "Set GEMINI_API_KEY=your_key_here in .env and restart the server.",
    ),
    (
        r"401|UNAUTHENTICATED|Invalid API key|API key",
        "The AI provider rejected authentication.",
        "Check GEMINI_API_KEY/HF_API_KEY and restart the server.",
    ),
    (
        r"429|RESOURCE_EXHAUSTED|rate.?limit",
        "The AI provider rate limit was reached.",
        "Wait and retry. ComicCraft uses automatic retries for transient AI failures.",
    ),
    (
        r"404|NOT_FOUND|model.*not found",
        "The configured AI model is unavailable or the model name is wrong.",
        "Check the model names in .env and use a model available to your API account.",
    ),
    (
        r"ConnectError|ConnectionError|Timeout|timed out|ReadTimeout",
        "A network or provider timeout occurred.",
        "Check internet access and retry. The generation pipeline has automatic retries.",
    ),
    (
        r"PermissionError",
        "Windows blocked access to a project file or generated folder.",
        "Close files using the project, then run VS Code/PowerShell normally and retry.",
    ),
    (
        r"Address already in use|WinError 10048",
        "Port 8000 is already being used.",
        "Stop the other server or run Uvicorn on another port.",
    ),
    (
        r"TemplateNotFound",
        "A Jinja2 template could not be found.",
        "Make sure the templates folder is at the project root and contains the required .html files.",
    ),
]


def decode(text: str) -> None:
    print("\n=== ComicCraft Error Decoder ===\n")
    matched = False

    for pattern, cause, fix in RULES:
        if re.search(pattern, text, flags=re.I | re.S):
            matched = True
            print(f"Likely cause: {cause}")
            print(f"Suggested action: {fix}\n")

    if not matched:
        print("No specific known pattern matched this error.")
        print("The original traceback is still useful. Look at the LAST exception")
        print("line first, then the first file in the traceback that belongs to ComicCraft.\n")

    lines = [line.strip() for line in text.splitlines() if line.strip()]
    exception_lines = [
        line for line in lines
        if re.search(r"(Error|Exception|Traceback|FAILED|ERROR)", line, re.I)
    ]

    if exception_lines:
        print("Important traceback lines:")
        for line in exception_lines[-8:]:
            print(f"  {line}")

    print("\nNext step:")
    print("  .\\scripts\\diagnose.ps1")
    print("\nThis decoder is intentionally offline; it does not send your traceback to any service.")


if __name__ == "__main__":
    decode(sys.stdin.read())
