from app.models import PromptRequest

def test_request():
    x=PromptRequest(story_prompt="fox adventure",character_name="Fenn",setting="forest")
    assert x.character_name=="Fenn"
